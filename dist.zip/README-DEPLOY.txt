NAMECHEAP SHARED HOSTING

Upload the CONTENTS of this folder (index.html, assets/, backend/, .htaccess,
database/, and this file) to the domain document root, commonly public_html/.
The ZIP archive is also rooted at these files; it does not add a dist folder.

DATABASE CONFIGURATION
1. In cPanel, create a MySQL database and user, and grant all privileges.
   cPanel may prefix both names with your account name.
2. Create $HOME/mcg-private outside the document root. Copy
   database.example.php to $HOME/mcg-private/database.php and enter the exact
   cPanel host, database, user, password, port, public HTTPS URL, and a
   writable storage path outside the web root. Never put real credentials in
   this package or in a web-accessible directory.
3. Only for a new, empty database, import database/schema.sql followed by
   database/seed.sql from your local repository. Both files are fresh-install
   only; seed.sql contains non-idempotent inserts and imported planner data.
   Never re-import them into production. Back up production data and use
   reviewed migrations for upgrades. Never upload seed.sql into the document
   root.
4. Set cPanel PHP to 8.1 or newer and enable PDO MySQL (pdo_mysql).
5. In cPanel Terminal from the document root run:
   php backend/tools/check_database.php
6. Create an administrator using your own email:
   php backend/tools/make_admin.php admin@your-domain.tld admin
   Save the generated temporary password securely and change it after login.

If the preflight reports a connection failure, verify cPanel's exact hostname,
port, prefixed database/user names and privileges. For further PHP failures,
read cPanel's PHP error log. Never share passwords when asking for help.
