NAMECHEAP SHARED HOSTING

Upload the CONTENTS of this folder (index.html, assets/, backend/, .htaccess,
database/, and this file) to the domain document root, commonly public_html/.
The ZIP archive is also rooted at these files; it does not add a dist folder.

DATABASE CONFIGURATION
1. In cPanel, create a MySQL database and user, and grant all privileges.
   cPanel may prefix both names with your account name.
2. Create $HOME/mcg-private outside the document root. Copy
   database.example.php to $HOME/mcg-private/database.php and enter the exact
   cPanel host, database, user, password, port, public HTTPS URL, and a
   writable storage path outside the web root. Never put real credentials in
   this package or in a web-accessible directory.
3. In phpMyAdmin, import database/schema.sql, then import the private
   database/seed.sql from your local repository. Do not upload seed.sql into
   the public document root.
4. Set cPanel PHP to 8.1 or newer and enable PDO MySQL (pdo_mysql).
5. In cPanel Terminal from the document root run:
   php backend/tools/check_database.php
6. Create an administrator using your own email:
   php backend/tools/make_admin.php admin@your-domain.tld admin
   Save the generated temporary password securely and change it after login.

If the preflight reports a connection failure, verify cPanel's exact hostname,
port, prefixed database/user names and privileges. For further PHP failures,
read cPanel's PHP error log. Never share passwords when asking for help.
